
ifvisible.setIdleDuration(10); //計算空閒持續時間

// 時間到時觸發
// ifvisible.idle(function () {
//   $('#timeOut').modal('show')
// });

// //啟動時
// ifvisible.wakeup(function () {
//   $('#timeOut').modal('hide')
// });
